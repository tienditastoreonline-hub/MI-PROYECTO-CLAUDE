# whatsapp-assistant

Headless AI agent frameworks like OpenClaw give your agent unfettered access to every connected service. This repo takes a different approach.

It builds a **WhatsApp AI assistant** powered by **Arcade**, where:
- **Arcade** manages per-action authorization and secure tool access
- **Claude Code (via MCP)** handles orchestration and reasoning
- **Skills** define workflows as simple markdown files anyone can read and edit

The result is a safer, more controllable, and more extensible agent architecture.

---

## 📚 Tutorial

Read the full walkthrough here:  
👉 https://www.arcade.dev/blog/secure-openclaw-alternative-arcade-claude-code

---

## ⚙️ What This Project Does

- Connects to the **WhatsApp Business API** via a relay server
- Processes incoming messages with an AI agent
- Uses **fine-grained permissions** for every external action
- Executes workflows defined as **editable markdown skills**
- Includes a **meeting prep skill** that pulls from:
  - Google Calendar
  - Gmail
  - Slack
- Handles reliability concerns like:
  - Cursor-based message deduplication
  - Webhook ingestion and replay safety

---

## 🧠 Why This Architecture

Traditional headless agents (e.g., OpenClaw-style systems) often:
- Have broad, persistent access to tools
- Lack per-action permissioning
- Are difficult to audit and control

This project flips that model by using **Arcade as the security layer**.

---

## 🧩 Tech Stack & What Each Piece Solves

### 🕹️ Arcade
**What it is:** A secure tool execution and authorization layer for AI agents  
**What it solves:**
- Enforces **per-action permissions** (not blanket access)
- Provides **user-scoped authentication** for services like Google/Slack
- Prevents agents from overreaching or misusing integrations
- Makes tool usage **auditable and controllable**

---

### 🤖 Claude Code (via MCP)
**What it is:** The orchestration engine for the agent  
**What it solves:**
- Decides **what actions to take** based on user input
- Coordinates multi-step workflows
- Interfaces with tools through **Model Context Protocol (MCP)**
- Keeps logic centralized instead of hardcoding flows

---

### 🧾 Skills (Markdown Workflows)
**What they are:** Human-readable workflow definitions  
**What they solve:**
- Allow **non-engineers to edit agent behavior**
- Make workflows **transparent and versionable**
- Reduce the need for complex code changes
- Enable fast iteration on agent capabilities

---

### 📡 WhatsApp Relay Server
**What it is:** A lightweight server for handling WhatsApp webhooks  
**What it solves:**
- Receives and normalizes incoming messages
- Ensures **reliable delivery and processing**
- Handles **deduplication** using cursors
- Bridges WhatsApp with the AI agent system

---

### 🔗 External Integrations (Google, Slack, etc.)
**What they solve:**
- Provide real-world context (emails, meetings, messages)
- Enable useful workflows like:
  - Meeting preparation
  - Context aggregation
  - Cross-app summarization

All access is mediated through **Arcade**, ensuring security and consent.

---

## 🔐 Key Design Principles

- **Least privilege by default** — every action must be explicitly authorized  
- **Human-readable workflows** — logic lives in markdown, not opaque code  
- **Composable architecture** — swap or extend components easily  
- **User-controlled integrations** — no hidden or persistent access  

