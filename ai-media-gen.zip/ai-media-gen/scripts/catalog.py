"""Catalogo de modelos y traduccion de parametros a cada proveedor.

Este modulo existe porque el mismo modelo se pide de forma distinta en Kie.ai y en
fal.ai. Ejemplos reales de la divergencia que absorbemos aqui:

  - GPT Image 2: Kie acepta `aspect_ratio` + `resolution`; fal no los tiene y espera
    `image_size` (preset o {width,height}) + `quality`.
  - Seedance 2.5: Kie es un unico modelo donde imagen-a-video se expresa con
    `first_frame_url`; fal parte el modelo en tres endpoints distintos.
  - Veo 3.1: en Kie ni siquiera vive en /jobs/createTask, tiene endpoint propio.
  - Kling 3.0: en fal el image-to-video ignora el aspect ratio (lo hereda de la imagen).

La idea es que quien llama trabaje siempre con `Options` (parametros normalizados) y
que cada modelo sepa convertirlos al dialecto de cada proveedor. Cuando una traduccion
pierde informacion (un ratio que el proveedor no soporta, un parametro que ignora), el
adaptador lo registra en `notes` en vez de callarselo: saber que te dieron 16:9 cuando
pediste 8:1 evita horas de confusion mirando el resultado.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Callable

# --------------------------------------------------------------------------------------
# Opciones normalizadas
# --------------------------------------------------------------------------------------


@dataclass
class Options:
    """Parametros tal y como los expresa el usuario, antes de traducir a un proveedor."""

    prompt: str = ""
    refs: tuple[str, ...] = ()          # imagenes de referencia o de edicion
    ref_videos: tuple[str, ...] = ()    # solo Seedance
    ref_audios: tuple[str, ...] = ()    # solo Seedance
    first_frame: str | None = None
    last_frame: str | None = None
    aspect_ratio: str | None = None
    resolution: str | None = None
    output_format: str | None = None
    duration: str | None = None
    audio: bool | None = None
    n: int = 1
    seed: int | None = None
    quality: str | None = None          # solo Veo: quality | fast | lite
    mode: str | None = None             # solo Kling: std | pro | 4K
    negative_prompt: str | None = None


# El nombre interno del parametro no siempre coincide con el flag del CLI: decir
# "--refs no es valido" cuando el flag real es "--ref" manda a quien lo lea directo a
# otro error. Una sola tabla para mensajes de error y para `models`.
_FLAGS = {
    "output_format": "--format",
    "refs": "--ref",
    "ref_videos": "--ref-video",
    "ref_audios": "--ref-audio",
}


def flag_for(param_name: str) -> str:
    return _FLAGS.get(param_name, "--" + param_name.replace("_", "-"))


@dataclass(frozen=True)
class Param:
    """Un parametro admitido por un modelo, con sus valores validos.

    Se declara una sola vez y sirve para tres cosas: validar antes de gastar creditos,
    imprimir `models` sin duplicar informacion, y documentar los defaults que aplicamos
    nosotros (no los del proveedor, para que Kie y fal den resultados comparables).
    """

    name: str
    choices: tuple[str, ...] | None = None
    rng: tuple[int, int] | None = None
    default: str | int | bool | None = None
    help: str = ""

    def describe(self) -> str:
        if self.choices and self.rng:
            allowed = f"{'|'.join(self.choices)} o {self.rng[0]}-{self.rng[1]}"
        elif self.choices:
            allowed = "|".join(self.choices)
        elif self.rng:
            allowed = f"{self.rng[0]}-{self.rng[1]}"
        else:
            allowed = "texto libre"
        suffix = f" (def. {self.default})" if self.default is not None else ""
        return f"{allowed}{suffix}"

    def accepts(self, value: str) -> bool:
        if self.choices and value in self.choices:
            return True
        if self.rng:
            try:
                return self.rng[0] <= int(value) <= self.rng[1]
            except (TypeError, ValueError):
                return False
        return self.choices is None and self.rng is None


@dataclass
class ProviderRequest:
    """Peticion ya traducida, lista para enviar."""

    provider: str            # "kie" | "fal"
    endpoint: str            # "market"/"veo" en Kie; el endpoint id en fal
    payload: dict
    notes: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class Model:
    key: str
    kind: str                # "image" | "video"
    label: str
    best_for: str
    cost_hint: str
    params: tuple[Param, ...]
    build_kie: Callable[[Options], ProviderRequest]
    build_fal: Callable[[Options], ProviderRequest]

    def param(self, name: str) -> Param | None:
        return next((p for p in self.params if p.name == name), None)


# --------------------------------------------------------------------------------------
# Utilidades de traduccion
# --------------------------------------------------------------------------------------

_RES_LONG_EDGE = {"1K": 1024, "2K": 2048, "4K": 4096}

# Ratios que fal admite en los modelos de imagen que exponen `aspect_ratio` tal cual.
_FAL_IMAGE_RATIOS = ("auto", "21:9", "16:9", "3:2", "4:3", "5:4", "1:1", "4:5", "3:4", "2:3", "9:16")


def _ratio_value(ratio: str) -> float:
    w, h = ratio.split(":")
    return int(w) / int(h)


def _closest_ratio(ratio: str, supported: tuple[str, ...]) -> str:
    """Ratio soportado mas parecido, para no romper cuando un proveedor va mas corto."""
    candidates = [r for r in supported if r != "auto"]
    return min(candidates, key=lambda r: abs(_ratio_value(r) - _ratio_value(ratio)))


def _fit_ratio(ratio: str | None, supported: tuple[str, ...], notes: list[str]) -> str | None:
    if ratio is None or ratio in supported:
        return ratio
    fallback = _closest_ratio(ratio, supported)
    notes.append(f"aspect_ratio {ratio} no existe en este proveedor; se usa {fallback}")
    return fallback


def _ratio_to_image_size(ratio: str | None, resolution: str | None) -> str | dict:
    """Convierte ratio + resolucion al `image_size` que espera fal.

    fal ofrece presets, pero solo cubren un punado de ratios y siempre a ~1K. Calcular
    ancho y alto explicitos es lo unico que respeta a la vez el ratio pedido y el salto
    a 2K/4K. Redondeamos a multiplos de 16 porque los backends de imagen suelen exigir
    dimensiones alineadas.
    """
    if ratio in (None, "auto"):
        return "auto"
    long_edge = _RES_LONG_EDGE.get(resolution or "1K", 1024)
    w_r, h_r = (int(x) for x in ratio.split(":"))
    if w_r >= h_r:
        width = long_edge
        height = max(16, round(long_edge * h_r / w_r / 16) * 16)
    else:
        height = long_edge
        width = max(16, round(long_edge * w_r / h_r / 16) * 16)
    return {"width": width, "height": height}


def _fal_format(fmt: str | None) -> str | None:
    """Kie dice `jpg`, fal dice `jpeg`. Un clasico de los 422 silenciosos."""
    return {"jpg": "jpeg"}.get(fmt, fmt)


def _kie_format(fmt: str | None, notes: list[str]) -> str | None:
    if fmt == "webp":
        notes.append("Kie no genera webp en este modelo; se usa png")
        return "png"
    return fmt


def _compact(payload: dict) -> dict:
    """Quita claves None para no mandar campos vacios que algunos endpoints rechazan."""
    return {k: v for k, v in payload.items() if v not in (None, (), [])}


def _all_image_refs(opts: Options) -> list[str]:
    """Referencias de imagen en orden, incluyendo frames si el modelo no los distingue."""
    refs = [r for r in (opts.first_frame, *opts.refs, opts.last_frame) if r]
    return refs


# --------------------------------------------------------------------------------------
# GPT Image 2
# --------------------------------------------------------------------------------------

_GPT_RATIOS = (
    "auto", "1:1", "3:2", "2:3", "4:3", "3:4", "5:4", "4:5", "16:9", "9:16",
    "2:1", "1:2", "3:1", "1:3", "21:9", "9:21",
)


def _gpt_image_kie(o: Options) -> ProviderRequest:
    notes: list[str] = []
    refs = _all_image_refs(o)
    payload = {
        "prompt": o.prompt,
        "aspect_ratio": o.aspect_ratio,
        "resolution": o.resolution,
    }
    if refs:
        model = "gpt-image-2-image-to-image"
        payload["input_urls"] = refs[:16]
        if len(refs) > 16:
            notes.append("Kie acepta 16 imagenes como maximo; se recortan las sobrantes")
    else:
        model = "gpt-image-2-text-to-image"
    if o.n > 1:
        notes.append("Kie genera 1 imagen por tarea; se lanzan tareas repetidas")
    return ProviderRequest("kie", "market", {"model": model, "input": _compact(payload)}, notes)


def _gpt_image_fal(o: Options) -> ProviderRequest:
    notes: list[str] = []
    refs = _all_image_refs(o)
    payload = {
        "prompt": o.prompt,
        "image_size": _ratio_to_image_size(o.aspect_ratio, o.resolution),
        "quality": "high",
        "num_images": o.n,
        "output_format": _fal_format(o.output_format),
    }
    if refs:
        endpoint = "openai/gpt-image-2/edit-image"
        payload["image_urls"] = refs[:16]
    else:
        endpoint = "openai/gpt-image-2/text-to-image"
    if o.resolution and o.resolution != "1K":
        notes.append(f"fal no tiene selector 1K/2K/4K; {o.resolution} se traduce a width/height")
    return ProviderRequest("fal", endpoint, _compact(payload), notes)


# --------------------------------------------------------------------------------------
# Nano Banana Pro / Nano Banana 2
# --------------------------------------------------------------------------------------

_NB_PRO_RATIOS = ("auto", "1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9")
_NB2_RATIOS = _NB_PRO_RATIOS + ("1:4", "4:1", "1:8", "8:1")


def _nano_kie(model: str, max_refs: int) -> Callable[[Options], ProviderRequest]:
    def build(o: Options) -> ProviderRequest:
        notes: list[str] = []
        refs = _all_image_refs(o)
        payload = {
            "prompt": o.prompt,
            "aspect_ratio": o.aspect_ratio,
            "resolution": o.resolution,
            "output_format": _kie_format(o.output_format, notes),
        }
        if refs:
            payload["image_input"] = refs[:max_refs]
            if len(refs) > max_refs:
                notes.append(f"{model} admite {max_refs} imagenes; se recortan las sobrantes")
        if o.n > 1:
            notes.append("Kie genera 1 imagen por tarea; se lanzan tareas repetidas")
        return ProviderRequest("kie", "market", {"model": model, "input": _compact(payload)}, notes)

    return build


def _nano_fal(base: str) -> Callable[[Options], ProviderRequest]:
    def build(o: Options) -> ProviderRequest:
        notes: list[str] = []
        refs = _all_image_refs(o)
        payload = {
            "prompt": o.prompt,
            "aspect_ratio": _fit_ratio(o.aspect_ratio, _FAL_IMAGE_RATIOS, notes),
            "resolution": o.resolution,
            "output_format": _fal_format(o.output_format),
            "num_images": o.n,
            "seed": o.seed,
        }
        endpoint = f"{base}/edit" if refs else base
        if refs:
            payload["image_urls"] = refs
        return ProviderRequest("fal", endpoint, _compact(payload), notes)

    return build


# --------------------------------------------------------------------------------------
# Seedance 2.5
# --------------------------------------------------------------------------------------

_SEEDANCE_RATIOS = ("auto", "21:9", "16:9", "4:3", "1:1", "3:4", "9:16")


def _seedance_kie(o: Options) -> ProviderRequest:
    notes: list[str] = []
    # Kie llama "adaptive" a lo que el resto del mundo llama "auto".
    ratio = "adaptive" if o.aspect_ratio == "auto" else o.aspect_ratio
    duration = -1 if o.duration == "auto" else int(o.duration) if o.duration else None
    payload = {
        "prompt": o.prompt,
        "duration": duration,
        "resolution": o.resolution,
        "aspect_ratio": ratio,
        "generate_audio": o.audio,
        "first_frame_url": o.first_frame,
        "last_frame_url": o.last_frame,
        "reference_image_urls": list(o.refs)[:30] or None,
        "reference_video_urls": list(o.ref_videos)[:10] or None,
        "reference_audio_urls": list(o.ref_audios)[:10] or None,
    }
    return ProviderRequest(
        "kie", "market", {"model": "bytedance/seedance-2-5", "input": _compact(payload)}, notes
    )


def _seedance_fal(o: Options) -> ProviderRequest:
    """fal parte Seedance en tres endpoints; elegimos segun que referencias hay."""
    notes: list[str] = []
    payload = {
        "prompt": o.prompt,
        "duration": o.duration,
        "resolution": o.resolution,
        "generate_audio": o.audio,
    }
    if o.refs or o.ref_videos or o.ref_audios:
        endpoint = "bytedance/seedance-2.5/reference-to-video"
        payload["image_urls"] = list(o.refs)[:30] or None
        payload["video_urls"] = list(o.ref_videos)[:10] or None
        payload["audio_urls"] = list(o.ref_audios)[:10] or None
        payload["aspect_ratio"] = _fit_ratio(o.aspect_ratio, _SEEDANCE_RATIOS, notes)
        if o.first_frame:
            notes.append("fal no combina first_frame con referencias; el frame pasa como referencia")
            payload["image_urls"] = [o.first_frame, *(payload["image_urls"] or [])][:30]
    elif o.first_frame:
        endpoint = "bytedance/seedance-2.5/image-to-video"
        payload["image_url"] = o.first_frame
        payload["end_image_url"] = o.last_frame
        if o.aspect_ratio and o.aspect_ratio != "auto":
            notes.append("image-to-video hereda el ratio de la imagen; se ignora aspect_ratio")
    else:
        endpoint = "bytedance/seedance-2.5/text-to-video"
        payload["aspect_ratio"] = _fit_ratio(o.aspect_ratio, _SEEDANCE_RATIOS, notes)
    return ProviderRequest("fal", endpoint, _compact(payload), notes)


# --------------------------------------------------------------------------------------
# Veo 3.1
# --------------------------------------------------------------------------------------

_VEO_KIE_MODELS = {"quality": "veo3", "fast": "veo3_fast", "lite": "veo3_lite"}


def _veo_kie(o: Options) -> ProviderRequest:
    """Veo no vive en el mercado de Kie: tiene endpoint, estados y campos propios."""
    notes: list[str] = []
    refs = _all_image_refs(o)
    if len(refs) > 3:
        notes.append("Veo admite 3 imagenes como maximo; se recortan las sobrantes")
        refs = refs[:3]
    model = _VEO_KIE_MODELS.get(o.quality or "quality", "veo3")

    # Solo forzamos generationType cuando la intencion es inequivoca. Con una unica
    # imagen de partida dejamos que Kie lo deduzca: marcarla como REFERENCE_2_VIDEO
    # obligaria a bajar a fast/lite y perderiamos la calidad que se pidio sin motivo.
    if o.first_frame and o.last_frame:
        generation_type = "FIRST_AND_LAST_FRAMES_2_VIDEO"
    elif o.refs:
        generation_type = "REFERENCE_2_VIDEO"
        if model == "veo3":
            model = "veo3_fast"
            notes.append("las referencias de material solo existen en fast/lite; se usa veo3_fast")
    else:
        generation_type = "TEXT_2_VIDEO" if not refs else None
    if o.audio is False:
        notes.append("Veo en Kie genera audio siempre; no se puede desactivar")
    payload = {
        "prompt": o.prompt,
        "model": model,
        "aspect_ratio": "Auto" if o.aspect_ratio == "auto" else o.aspect_ratio,
        "resolution": o.resolution,
        "duration": int(o.duration) if o.duration else None,
        "imageUrls": refs or None,
        "generationType": generation_type,
    }
    return ProviderRequest("kie", "veo", _compact(payload), notes)


def _veo_fal(o: Options) -> ProviderRequest:
    notes: list[str] = []
    refs = _all_image_refs(o)
    payload = {
        "prompt": o.prompt,
        # fal espera "8s", Kie espera 8. Mandar el entero aqui devuelve 422.
        "duration": f"{o.duration}s" if o.duration else None,
        "resolution": o.resolution,
        "aspect_ratio": o.aspect_ratio,
        "generate_audio": o.audio,
        "negative_prompt": o.negative_prompt,
        "seed": o.seed,
    }
    if refs:
        endpoint = "fal-ai/veo3.1/image-to-video"
        payload["image_url"] = refs[0]
        if len(refs) > 1:
            notes.append("fal usa una sola imagen de partida en Veo; se ignoran las demas")
    else:
        endpoint = "fal-ai/veo3.1"
    if o.quality and o.quality != "quality":
        notes.append(f"fal no expone la variante {o.quality} de Veo; se usa la estandar")
    return ProviderRequest("fal", endpoint, _compact(payload), notes)


# --------------------------------------------------------------------------------------
# Kling 3.0
# --------------------------------------------------------------------------------------


def _kling_kie(o: Options) -> ProviderRequest:
    notes: list[str] = []
    refs = _all_image_refs(o)
    payload = {
        "prompt": o.prompt,
        "duration": str(o.duration) if o.duration else None,
        "aspect_ratio": o.aspect_ratio,
        "mode": o.mode,
        "sound": o.audio,
        "image_urls": refs[:2] or None,
    }
    if len(refs) > 2:
        notes.append("Kling usa primer y ultimo frame; se ignoran el resto de imagenes")
    return ProviderRequest(
        "kie", "market", {"model": "kling-3.0/video", "input": _compact(payload)}, notes
    )


def _kling_fal(o: Options) -> ProviderRequest:
    notes: list[str] = []
    tier = "standard" if o.mode == "std" else "pro"
    if o.mode == "4K":
        notes.append("fal no ofrece el modo 4K de Kling; se usa pro (1080p)")
    payload = {
        "prompt": o.prompt,
        "duration": str(o.duration) if o.duration else None,
        "generate_audio": o.audio,
        "negative_prompt": o.negative_prompt,
    }
    start = o.first_frame or (o.refs[0] if o.refs else None)
    if start:
        endpoint = f"fal-ai/kling-video/v3/{tier}/image-to-video"
        payload["start_image_url"] = start
        payload["end_image_url"] = o.last_frame
        if o.aspect_ratio:
            notes.append("el image-to-video de Kling hereda el ratio de la imagen; se ignora")
    else:
        endpoint = f"fal-ai/kling-video/v3/{tier}/text-to-video"
        payload["aspect_ratio"] = o.aspect_ratio
    return ProviderRequest("fal", endpoint, _compact(payload), notes)


# --------------------------------------------------------------------------------------
# Registro
# --------------------------------------------------------------------------------------

_IMAGE_COMMON = (
    Param("resolution", choices=("1K", "2K", "4K"), default="1K", help="resolucion de salida"),
    Param("output_format", choices=("png", "jpg", "webp"), default="png", help="formato de archivo"),
    Param("n", rng=(1, 4), default=1, help="numero de imagenes"),
)

MODELS: dict[str, Model] = {
    "gpt-image-2": Model(
        key="gpt-image-2",
        kind="image",
        label="GPT Image 2 (OpenAI)",
        best_for="maxima calidad, texto legible dentro de la imagen, foto de producto",
        cost_hint="el mas caro de los tres de imagen",
        params=(
            Param("aspect_ratio", choices=_GPT_RATIOS, default="1:1", help="proporcion"),
            *_IMAGE_COMMON,
            Param("refs", default=None, help="hasta 16 imagenes para editar/componer"),
        ),
        build_kie=_gpt_image_kie,
        build_fal=_gpt_image_fal,
    ),
    "nano-banana-pro": Model(
        key="nano-banana-pro",
        kind="image",
        label="Nano Banana Pro (Gemini 3 Pro Image)",
        best_for="imagen profesional a menor coste que GPT Image 2",
        cost_hint="intermedio (~4x mas barato que GPT Image 2)",
        params=(
            Param("aspect_ratio", choices=_NB_PRO_RATIOS, default="1:1", help="proporcion"),
            *_IMAGE_COMMON,
            Param("seed", help="semilla para reproducir un resultado (solo fal)"),
            Param("refs", default=None, help="hasta 8 imagenes de referencia"),
        ),
        build_kie=_nano_kie("nano-banana-pro", 8),
        build_fal=_nano_fal("fal-ai/nano-banana-pro"),
    ),
    "nano-banana-2": Model(
        key="nano-banana-2",
        kind="image",
        label="Nano Banana 2 (Gemini 3.1 Flash Image)",
        best_for="edicion de imagen y generacion en volumen a bajo coste",
        cost_hint="el mas barato",
        params=(
            Param("aspect_ratio", choices=_NB2_RATIOS, default="1:1", help="proporcion"),
            *_IMAGE_COMMON,
            Param("seed", help="semilla para reproducir un resultado (solo fal)"),
            Param("refs", default=None, help="hasta 14 imagenes de referencia"),
        ),
        build_kie=_nano_kie("nano-banana-2", 14),
        build_fal=_nano_fal("fal-ai/nano-banana-2"),
    ),
    "seedance-2.5": Model(
        key="seedance-2.5",
        kind="video",
        label="Seedance 2.5 (ByteDance)",
        best_for="video de hasta 30s con consistencia de personaje y audio nativo",
        cost_hint="por segundo de video; 30s cuesta ~6x lo que 5s",
        params=(
            Param("duration", choices=("auto",), rng=(4, 30), default="5", help="segundos"),
            Param("resolution", choices=("480p", "720p"), default="720p", help="resolucion"),
            Param("aspect_ratio", choices=_SEEDANCE_RATIOS, default="auto", help="proporcion"),
            Param("audio", choices=("true", "false"), default="true", help="audio nativo"),
            Param("first_frame", help="imagen de partida"),
            Param("last_frame", help="imagen de cierre"),
            Param("refs", help="hasta 30 imagenes de referencia"),
            Param("ref_videos", help="hasta 10 videos de referencia"),
            Param("ref_audios", help="hasta 10 audios de referencia"),
        ),
        build_kie=_seedance_kie,
        build_fal=_seedance_fal,
    ),
    "veo-3.1": Model(
        key="veo-3.1",
        kind="video",
        label="Veo 3.1 (Google DeepMind)",
        best_for="video fotorrealista con maximo detalle, clips cortos",
        cost_hint="caro en variante quality; fast cuesta bastante menos",
        params=(
            Param("duration", choices=("4", "6", "8"), default="8", help="segundos"),
            Param("resolution", choices=("720p", "1080p", "4k"), default="720p", help="resolucion"),
            Param("aspect_ratio", choices=("16:9", "9:16", "auto"), default="16:9", help="proporcion"),
            Param("quality", choices=("quality", "fast", "lite"), default="quality", help="variante"),
            Param("audio", choices=("true", "false"), default="true", help="audio nativo (solo fal)"),
            Param("first_frame", help="imagen de partida"),
            Param("last_frame", help="imagen de cierre (activa transicion)"),
            Param("refs", help="hasta 3 imagenes de referencia"),
        ),
        build_kie=_veo_kie,
        build_fal=_veo_fal,
    ),
    "kling-3.0": Model(
        key="kling-3.0",
        kind="video",
        label="Kling 3.0",
        best_for="maxima fidelidad al animar una imagen o un personaje de referencia",
        cost_hint="por segundo; el modo 4K multiplica el coste",
        params=(
            Param("duration", rng=(3, 15), default="5", help="segundos"),
            Param("aspect_ratio", choices=("16:9", "9:16", "1:1"), default="16:9", help="proporcion"),
            Param("mode", choices=("std", "pro", "4K"), default="pro", help="calidad/resolucion"),
            Param("audio", choices=("true", "false"), default="true", help="audio nativo"),
            Param("first_frame", help="imagen de partida"),
            Param("last_frame", help="imagen de cierre"),
        ),
        build_kie=_kling_kie,
        build_fal=_kling_fal,
    ),
}


def get(key: str) -> Model:
    if key not in MODELS:
        disponibles = ", ".join(MODELS)
        raise KeyError(f"modelo desconocido '{key}'. Disponibles: {disponibles}")
    return MODELS[key]


def apply_defaults(model: Model, opts: Options) -> Options:
    """Rellena lo que el usuario no fijo.

    Fijamos defaults propios en vez de dejar que cada proveedor aplique el suyo: si Kie
    cae y saltamos a fal, el resultado debe parecerse al que ibas a recibir, no cambiar
    de proporcion o de duracion por el camino.
    """
    updates: dict[str, object] = {}
    for p in model.params:
        if p.default is None:
            continue
        current = getattr(opts, p.name, None)
        if current in (None, ()):
            updates[p.name] = True if p.default == "true" else p.default
    return replace(opts, **updates) if updates else opts


def validate(model: Model, opts: Options) -> list[str]:
    """Errores de parametros, detectados antes de tocar la red.

    Validar aqui es lo que evita descubrir un enum mal puesto despues de que la peticion
    ya haya consumido creditos, o peor, despues de 8 minutos de polling.
    """
    errors: list[str] = []
    if not opts.prompt or not opts.prompt.strip():
        errors.append("falta --prompt")

    declared = {p.name for p in model.params}
    for p in model.params:
        value = getattr(opts, p.name, None)
        if value in (None, ()) or p.name == "refs":
            continue
        if p.name == "audio":
            continue  # booleano, ya normalizado por el CLI
        if not p.accepts(str(value)):
            errors.append(f"{flag_for(p.name)} '{value}' no es valido: {p.describe()}")

    # Parametros que el usuario paso pero este modelo no admite: mejor decirlo que
    # ignorarlos en silencio y que el resultado no se parezca a lo pedido.
    for name, label in (
        ("first_frame", "--first-frame"),
        ("last_frame", "--last-frame"),
        ("ref_videos", "--ref-video"),
        ("ref_audios", "--ref-audio"),
        ("mode", "--mode"),
        ("quality", "--quality"),
    ):
        if getattr(opts, name, None) and name not in declared:
            errors.append(f"{label} no aplica a {model.key}")

    if opts.refs and "refs" not in declared:
        errors.append(f"--ref no aplica a {model.key}")

    return errors


def build(model: Model, provider: str, opts: Options) -> ProviderRequest:
    return model.build_kie(opts) if provider == "kie" else model.build_fal(opts)
