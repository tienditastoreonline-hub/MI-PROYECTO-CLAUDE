"""Clientes de Kie.ai y fal.ai, subida de ficheros y logica de fallback.

Solo libreria estandar: la skill tiene que funcionar en cualquier proyecto sin un paso
previo de instalacion.

El reparto de responsabilidades es: `catalog` decide *que* mandar, este modulo se ocupa
de *como* mandarlo y de que un fallo en Kie no te deje sin resultado.
"""

from __future__ import annotations

import base64
import json
import mimetypes
import os
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass, field
from pathlib import Path

# --------------------------------------------------------------------------------------
# Errores
# --------------------------------------------------------------------------------------


class ConfigError(Exception):
    """Falta configuracion (claves, .env). No tiene sentido reintentar ni hacer fallback."""


class GenerationError(Exception):
    """El proveedor rechazo o no pudo completar la generacion."""

    def __init__(self, message: str, *, status: int | None = None, retryable: bool = False):
        super().__init__(message)
        self.status = status
        self.retryable = retryable


# --------------------------------------------------------------------------------------
# Configuracion
# --------------------------------------------------------------------------------------

# providers.py vive en <raiz>/.claude/skills/ai-media-gen/scripts/, asi que la raiz del
# proyecto son cuatro niveles arriba. Derivarlo del fichero y no del cwd es lo que
# permite invocar la skill desde cualquier subdirectorio sin perder el .env.
PROJECT_ROOT = Path(__file__).resolve().parents[4]
ENV_FILE = PROJECT_ROOT / ".env"


def _parse_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw = line.partition("=")
        value = raw.strip().strip('"').strip("'")
        if value:
            values[key.strip()] = value
    return values


@dataclass
class Config:
    kie_key: str | None
    fal_key: str | None
    kie_base: str
    fal_queue_base: str

    @classmethod
    def load(cls) -> "Config":
        env = _parse_env(ENV_FILE)
        return cls(
            kie_key=env.get("KIE_API_KEY"),
            fal_key=env.get("FAL_KEY") or env.get("FAL_API_KEY"),
            # Overridables para poder probar la ruta de fallback sin gastar creditos.
            kie_base=env.get("KIE_BASE_URL", os.environ.get("KIE_BASE_URL", "https://api.kie.ai")),
            fal_queue_base=env.get(
                "FAL_QUEUE_URL", os.environ.get("FAL_QUEUE_URL", "https://queue.fal.run")
            ),
        )

    def require(self, provider: str) -> str:
        key = self.kie_key if provider == "kie" else self.fal_key
        if key:
            return key
        var = "KIE_API_KEY" if provider == "kie" else "FAL_KEY"
        origen = "kie.ai/api-key" if provider == "kie" else "fal.ai/dashboard/keys"
        raise ConfigError(
            f"falta {var} en {ENV_FILE}.\n"
            f"Copia .env.example a .env y pon tu clave (se obtiene en {origen})."
        )


# --------------------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------------------

_SSL_CTX = ssl.create_default_context()
_RETRYABLE_STATUS = {408, 425, 429, 500, 501, 502, 503, 504, 505}

# El CDN donde Kie deja los resultados responde 403 al User-Agent por defecto de urllib.
_USER_AGENT = "Mozilla/5.0 (compatible; ai-media-gen/1.0)"


def _request(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: bytes | None = None,
    timeout: int = 60,
) -> tuple[int, bytes]:
    headers = dict(headers or {})
    headers.setdefault("User-Agent", _USER_AGENT)
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_SSL_CTX) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()
    except urllib.error.URLError as exc:
        raise GenerationError(f"error de red: {exc.reason}", retryable=True) from exc
    except TimeoutError as exc:
        raise GenerationError("timeout de conexion", retryable=True) from exc


def _json_request(url: str, **kwargs) -> dict:
    payload = kwargs.pop("json_body", None)
    headers = dict(kwargs.pop("headers", {}))
    if payload is not None:
        headers["Content-Type"] = "application/json"
        kwargs["body"] = json.dumps(payload).encode("utf-8")
        kwargs.setdefault("method", "POST")
    status, raw = _request(url, headers=headers, **kwargs)
    try:
        data = json.loads(raw or b"{}")
    except json.JSONDecodeError:
        raise GenerationError(
            f"respuesta no-JSON ({status}): {raw[:200].decode('utf-8', 'replace')}",
            status=status,
            retryable=status in _RETRYABLE_STATUS,
        )
    # Kie devuelve a veces HTTP 200 con el error real en `code`, asi que hay que mirar
    # los dos sitios antes de dar una peticion por buena.
    code = data.get("code") if isinstance(data, dict) else None
    effective = code if isinstance(code, int) and code >= 400 else status
    if effective >= 400:
        msg = ""
        if isinstance(data, dict):
            msg = str(data.get("msg") or data.get("detail") or data.get("error") or "")
        raise GenerationError(
            f"{_explain(effective)} (HTTP {effective}){': ' + msg if msg else ''}",
            status=effective,
            retryable=effective in _RETRYABLE_STATUS,
        )
    return data


def _explain(status: int) -> str:
    return {
        401: "clave de API invalida o caducada",
        402: "sin creditos suficientes",
        403: "acceso denegado",
        404: "endpoint o tarea no encontrada",
        422: "parametros rechazados por el proveedor",
        429: "limite de peticiones alcanzado",
        433: "modelo no disponible temporalmente",
        455: "servicio en mantenimiento",
    }.get(status, "error del proveedor")


# --------------------------------------------------------------------------------------
# Resultado
# --------------------------------------------------------------------------------------


@dataclass
class Result:
    provider: str
    endpoint: str
    urls: list[str]
    elapsed: float
    credits: float | None = None
    notes: list[str] = field(default_factory=list)
    attempts: list[str] = field(default_factory=list)


# URLs de control, no de contenido: nunca son el resultado.
_IGNORED_KEYS = {"status_url", "response_url", "cancel_url", "callBackUrl"}

# Campos que si contienen media, pero no la que el usuario pidio. Veo, por ejemplo,
# devuelve `resultUrls` (el video final) junto a `originUrls` (el original antes de
# extender): entregar el segundo seria darle un video distinto del que encargo.
_SECONDARY_KEYS = {
    "originUrls", "origin_urls", "originUrl",
    "thumbnail_url", "thumbnailUrl", "thumbnail", "preview_url", "coverUrl", "cover_url",
    "first_frame_url", "last_frame_url", "image_url", "image_urls", "input_urls",
}

_MEDIA_EXT = (".mp4", ".mov", ".webm", ".png", ".jpg", ".jpeg", ".webp")


def _harvest_urls(blob) -> list[str]:
    """Extrae URLs de salida de una respuesta sin depender del nombre exacto del campo.

    Cada modelo devuelve lo suyo (`resultUrls`, `images[].url`, `video.url`) y los
    nombres cambian entre variantes. Recorrer la estructura es mas robusto que mantener
    un mapa de rutas por modelo que se rompe en cuanto un endpoint anade un campo; lo
    que si mantenemos es que campo gana cuando hay varios candidatos.
    """
    primary: list[str] = []
    secondary: list[str] = []

    def walk(node, key: str = ""):
        if isinstance(node, str):
            if node.startswith("http") and key not in _IGNORED_KEYS:
                (secondary if key in _SECONDARY_KEYS else primary).append(node)
        elif isinstance(node, dict):
            for k, v in node.items():
                walk(v, k)
        elif isinstance(node, (list, tuple)):
            for item in node:
                walk(item, key)

    walk(blob)
    for bucket in (primary, secondary):
        # Dentro de cada nivel, un fichero de media gana a una URL suelta cualquiera.
        media = [u for u in bucket if any(e in u.lower() for e in _MEDIA_EXT)]
        if media:
            bucket[:] = media
    return list(dict.fromkeys(primary + secondary))


# --------------------------------------------------------------------------------------
# Kie.ai
# --------------------------------------------------------------------------------------


class KieClient:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.key = cfg.require("kie")

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.key}"}

    def run(self, endpoint: str, payload: dict, *, timeout: int, interval: int, log) -> Result:
        started = time.monotonic()
        if endpoint == "veo":
            task_id = self._submit_veo(payload)
            log(f"kie: tarea Veo {task_id} enviada")
            data = self._poll(f"{self.cfg.kie_base}/api/v1/veo/record-info", task_id,
                              self._veo_state, timeout=timeout, interval=interval, log=log)
        else:
            task_id = self._submit_market(payload)
            log(f"kie: tarea {task_id} enviada")
            data = self._poll(f"{self.cfg.kie_base}/api/v1/jobs/recordInfo", task_id,
                              self._market_state, timeout=timeout, interval=interval, log=log)
        urls = _harvest_urls(data)
        if not urls:
            raise GenerationError("Kie completo la tarea pero no devolvio ninguna URL")
        return Result("kie", endpoint, urls, time.monotonic() - started,
                      credits=data.get("creditsConsumed"))

    def _submit_market(self, payload: dict) -> str:
        data = _json_request(
            f"{self.cfg.kie_base}/api/v1/jobs/createTask",
            headers=self._headers, json_body=payload, timeout=90,
        )
        task_id = (data.get("data") or {}).get("taskId")
        if not task_id:
            raise GenerationError(f"Kie no devolvio taskId: {json.dumps(data)[:200]}")
        return task_id

    def _submit_veo(self, payload: dict) -> str:
        data = _json_request(
            f"{self.cfg.kie_base}/api/v1/veo/generate",
            headers=self._headers, json_body=payload, timeout=90,
        )
        task_id = (data.get("data") or {}).get("taskId")
        if not task_id:
            raise GenerationError(f"Kie no devolvio taskId: {json.dumps(data)[:200]}")
        return task_id

    @staticmethod
    def _market_state(data: dict) -> tuple[str, str, dict]:
        state = data.get("state", "")
        # Las claves existen con valor nulo cuando no hay fallo, asi que el default del
        # .get() no llega a aplicarse: hay que descartar los None a mano.
        detail = " ".join(str(x) for x in (data.get("failCode"), data.get("failMsg")) if x)
        result = data
        raw = data.get("resultJson")
        if isinstance(raw, str) and raw.strip():
            # `resultJson` llega como string con JSON dentro; hay que parsearlo aparte.
            try:
                result = {**data, "result": json.loads(raw)}
            except json.JSONDecodeError:
                pass
        status = {"success": "done", "fail": "failed"}.get(state, "running")
        return status, detail or state, result

    @staticmethod
    def _veo_state(data: dict) -> tuple[str, str, dict]:
        flag = data.get("successFlag")
        detail = f"{data.get('errorCode') or ''} {data.get('errorMessage') or ''}".strip()
        status = {1: "done", 2: "failed", 3: "failed"}.get(flag, "running")
        return status, detail or f"successFlag={flag}", data

    def _poll(self, url: str, task_id: str, reader, *, timeout: int, interval: int, log) -> dict:
        deadline = time.monotonic() + timeout
        last = ""
        while time.monotonic() < deadline:
            time.sleep(interval)
            body = _json_request(f"{url}?taskId={urllib.parse.quote(task_id)}",
                                 headers=self._headers, timeout=60)
            data = body.get("data") or {}
            status, detail, payload = reader(data)
            if status == "done":
                return payload
            if status == "failed":
                raise GenerationError(f"Kie no pudo generar: {detail}")
            if detail != last:
                log(f"kie: {detail}")
                last = detail
        raise GenerationError(f"Kie sigue generando tras {timeout}s", retryable=True)


# --------------------------------------------------------------------------------------
# fal.ai
# --------------------------------------------------------------------------------------


class FalClient:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.key = cfg.require("fal")

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Key {self.key}"}

    def run(self, endpoint: str, payload: dict, *, timeout: int, interval: int, log) -> Result:
        started = time.monotonic()
        submit = _json_request(
            f"{self.cfg.fal_queue_base}/{endpoint}",
            headers=self._headers, json_body=payload, timeout=90,
        )
        # Usamos las URLs que devuelve fal en vez de componerlas: en endpoints con
        # subrutas (kling-video/v3/pro/...) la base de status no coincide con la de
        # submit, y reconstruirla a mano acaba en 404.
        status_url = submit.get("status_url")
        response_url = submit.get("response_url")
        request_id = submit.get("request_id", "?")
        if not status_url or not response_url:
            raise GenerationError(f"fal no devolvio status_url: {json.dumps(submit)[:200]}")
        log(f"fal: peticion {request_id} en cola")

        deadline = time.monotonic() + timeout
        last = ""
        while time.monotonic() < deadline:
            time.sleep(interval)
            state = _json_request(status_url, headers=self._headers, timeout=60)
            status = state.get("status", "")
            if status == "COMPLETED":
                data = _json_request(response_url, headers=self._headers, timeout=120)
                urls = _harvest_urls(data)
                if not urls:
                    raise GenerationError("fal completo la peticion pero no devolvio URLs")
                return Result("fal", endpoint, urls, time.monotonic() - started)
            if status in {"ERROR", "FAILED"}:
                raise GenerationError(f"fal no pudo generar: {json.dumps(state)[:300]}")
            if status != last:
                log(f"fal: {status.lower() or 'esperando'}")
                last = status
        raise GenerationError(f"fal sigue generando tras {timeout}s", retryable=True)


# --------------------------------------------------------------------------------------
# Subida de ficheros locales
# --------------------------------------------------------------------------------------


def upload_asset(path_or_url: str, cfg: Config, log) -> str:
    """Convierte una ruta local en URL publica; deja pasar las URLs tal cual.

    Subimos preferentemente a Kie y reutilizamos esa URL tambien si acabamos generando
    en fal: si Kie falla a mitad, no queremos resubir 30 MB de referencias otra vez.
    Los ficheros de Kie caducan a los 3 dias, asi que sirve para generar pero no como
    almacenamiento.
    """
    if path_or_url.startswith(("http://", "https://")):
        return path_or_url

    path = Path(path_or_url).expanduser()
    if not path.is_file():
        raise ConfigError(f"no encuentro el fichero '{path_or_url}'")
    raw = path.read_bytes()
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    log(f"subiendo {path.name} ({len(raw) // 1024} KB)")

    if cfg.kie_key:
        try:
            return _upload_kie(raw, path.name, mime, cfg)
        except (GenerationError, ConfigError) as exc:
            log(f"subida a Kie fallida ({exc}); probando fal")
    if cfg.fal_key:
        return _upload_fal(raw, path.name, mime, cfg)
    raise ConfigError("no hay ninguna clave configurada para subir ficheros")


def _upload_kie(raw: bytes, name: str, mime: str, cfg: Config) -> str:
    data = _json_request(
        "https://kieai.redpandaai.co/api/file-base64-upload",
        headers={"Authorization": f"Bearer {cfg.kie_key}"},
        json_body={
            "base64Data": f"data:{mime};base64,{base64.b64encode(raw).decode()}",
            "uploadPath": "images/ai-media-gen",
            "fileName": f"{uuid.uuid4().hex[:8]}-{name}",
        },
        timeout=180,
    )
    urls = _harvest_urls(data.get("data") or data)
    if not urls:
        raise GenerationError(f"la subida a Kie no devolvio URL: {json.dumps(data)[:200]}")
    return urls[0]


def _upload_fal(raw: bytes, name: str, mime: str, cfg: Config) -> str:
    token = _json_request(
        "https://rest.alpha.fal.ai/storage/auth/token?storage_type=fal-cdn-v3",
        headers={"Authorization": f"Key {cfg.fal_key}"},
        json_body={},
        timeout=60,
    )
    base = token.get("base_url", "").rstrip("/")
    if not base or not token.get("token"):
        raise GenerationError("fal no devolvio credenciales de subida")
    status, body = _request(
        f"{base}/files/upload",
        method="POST",
        headers={"Authorization": f"Bearer {token['token']}", "Content-Type": mime},
        body=raw,
        timeout=300,
    )
    if status >= 400:
        raise GenerationError(f"subida a fal fallida (HTTP {status})", status=status)
    urls = _harvest_urls(json.loads(body or b"{}"))
    if not urls:
        raise GenerationError("la subida a fal no devolvio URL")
    return urls[0]


# --------------------------------------------------------------------------------------
# Orquestacion con fallback
# --------------------------------------------------------------------------------------

_CLIENTS = {"kie": KieClient, "fal": FalClient}


def run_with_fallback(
    requests_by_provider: dict[str, "object"],
    order: list[str],
    cfg: Config,
    *,
    timeout: int,
    interval: int,
    log,
    retries: int = 2,
) -> Result:
    """Recorre los proveedores en orden hasta que uno entrega.

    Dentro de un proveedor reintentamos solo los fallos transitorios (red, 5xx, 429) con
    backoff: insistir ante un 402 o un 422 solo quema tiempo. Cuando el proveedor esta
    agotado pasamos al siguiente, que es exactamente el caso para el que existe fal aqui.
    """
    attempts: list[str] = []
    config_errors: list[str] = []
    last: Exception | None = None

    for provider in order:
        req = requests_by_provider.get(provider)
        if req is None:
            continue
        try:
            client = _CLIENTS[provider](cfg)
        except ConfigError as exc:
            # No lo contamos como intento: no llego a salir ninguna peticion. Si acaban
            # asi todos los proveedores, el problema es de configuracion, no del modelo,
            # y conviene que quien lo lea lo distinga de un fallo de generacion.
            config_errors.append(str(exc))
            last = exc
            continue

        for intento in range(1, retries + 1):
            try:
                result = client.run(req.endpoint, req.payload,
                                    timeout=timeout, interval=interval, log=log)
                result.notes = list(req.notes)
                result.attempts = attempts
                return result
            except GenerationError as exc:
                last = exc
                attempts.append(f"{provider}: {exc}")
                if exc.retryable and intento < retries:
                    espera = 2 ** intento
                    log(f"{provider} fallo ({exc}); reintento en {espera}s")
                    time.sleep(espera)
                    continue
                log(f"{provider} agotado: {exc}")
                break

    if not attempts and config_errors:
        raise ConfigError("\n".join(dict.fromkeys(config_errors)))
    detalle = attempts + [f"{e} (proveedor no configurado)" for e in config_errors]
    raise GenerationError(
        "ningun proveedor pudo completar la generacion:\n  - " + "\n  - ".join(detalle or [str(last)])
    )


def download(url: str, dest: Path, log) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    status, raw = _request(url, timeout=600)
    if status >= 400:
        raise GenerationError(f"no pude descargar el resultado (HTTP {status})", status=status)
    dest.write_bytes(raw)
    log(f"guardado {dest} ({len(raw) // 1024} KB)")
    return dest
