#!/usr/bin/env python3
"""Genera imagenes y videos con Kie.ai como proveedor principal y fal.ai como respaldo.

Uso rapido:
    python genmedia.py models
    python genmedia.py image --model nano-banana-2 --prompt "un gato astronauta"
    python genmedia.py video --model seedance-2.5 --prompt "..." --duration 10

Anade --dry-run a cualquier comando para ver el JSON exacto que se enviaria a cada
proveedor sin gastar un solo credito.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import unicodedata
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import catalog  # noqa: E402
import providers  # noqa: E402
from catalog import Options  # noqa: E402
from providers import ConfigError, GenerationError  # noqa: E402

EXIT_OK, EXIT_CONFIG, EXIT_VALIDATION, EXIT_GENERATION = 0, 2, 3, 4

_MEDIA_EXT = {"image": ".png", "video": ".mp4"}

flag_for = catalog.flag_for


# --------------------------------------------------------------------------------------
# Salida
# --------------------------------------------------------------------------------------


def make_logger(quiet: bool):
    def log(message: str) -> None:
        if not quiet:
            print(f"  {message}", file=sys.stderr, flush=True)

    return log


def slugify(text: str, limit: int = 40) -> str:
    normal = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", normal).strip("-").lower()
    return (slug[:limit].rstrip("-")) or "sin-titulo"


def guess_extension(url: str, kind: str, fmt: str | None) -> str:
    match = re.search(r"\.(png|jpe?g|webp|mp4|mov|webm)(?:\?|$)", url, re.I)
    if match:
        return f".{match.group(1).lower()}"
    if fmt:
        return f".{'jpg' if fmt == 'jpeg' else fmt}"
    return _MEDIA_EXT[kind]


# --------------------------------------------------------------------------------------
# Comando `models`
# --------------------------------------------------------------------------------------


def cmd_models(args: argparse.Namespace) -> int:
    if args.json:
        payload = {
            key: {
                "kind": m.kind,
                "label": m.label,
                "best_for": m.best_for,
                "cost": m.cost_hint,
                "params": {p.name: p.describe() for p in m.params},
            }
            for key, m in catalog.MODELS.items()
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return EXIT_OK

    for kind, titulo in (("image", "IMAGEN"), ("video", "VIDEO")):
        print(f"\n{titulo}")
        print("=" * 78)
        for m in (x for x in catalog.MODELS.values() if x.kind == kind):
            print(f"\n  {m.key}  ->  {m.label}")
            print(f"    para : {m.best_for}")
            print(f"    coste: {m.cost_hint}")
            for p in m.params:
                print(f"    {flag_for(p.name):<16} {p.describe()}")
    print()
    return EXIT_OK


# --------------------------------------------------------------------------------------
# Generacion
# --------------------------------------------------------------------------------------


def build_options(args: argparse.Namespace) -> Options:
    audio = None
    if getattr(args, "audio", None) is not None:
        audio = args.audio
    return Options(
        prompt=args.prompt,
        refs=tuple(args.ref or ()),
        ref_videos=tuple(getattr(args, "ref_video", None) or ()),
        ref_audios=tuple(getattr(args, "ref_audio", None) or ()),
        first_frame=getattr(args, "first_frame", None),
        last_frame=getattr(args, "last_frame", None),
        aspect_ratio=args.aspect_ratio,
        resolution=args.resolution,
        output_format=getattr(args, "format", None),
        duration=str(args.duration) if getattr(args, "duration", None) else None,
        audio=audio,
        n=getattr(args, "n", 1),
        seed=getattr(args, "seed", None),
        quality=getattr(args, "quality", None),
        mode=getattr(args, "mode", None),
        negative_prompt=getattr(args, "negative_prompt", None),
    )


def resolve_assets(opts: Options, cfg: providers.Config, dry_run: bool, log) -> Options:
    """Sustituye rutas locales por URLs publicas.

    En dry-run no subimos nada: marcamos el fichero con un placeholder para que se vea
    en el payload donde acabaria cada referencia sin tocar la red.
    """
    def to_url(value: str | None) -> str | None:
        if not value:
            return None
        if value.startswith(("http://", "https://")):
            return value
        if dry_run:
            path = Path(value).expanduser()
            estado = "existe" if path.is_file() else "NO EXISTE"
            return f"<subida-pendiente:{path.name}:{estado}>"
        return providers.upload_asset(value, cfg, log)

    from dataclasses import replace

    return replace(
        opts,
        refs=tuple(to_url(r) for r in opts.refs),
        ref_videos=tuple(to_url(r) for r in opts.ref_videos),
        ref_audios=tuple(to_url(r) for r in opts.ref_audios),
        first_frame=to_url(opts.first_frame),
        last_frame=to_url(opts.last_frame),
    )


def provider_order(preferencia: str, allow_fallback: bool) -> list[str]:
    if preferencia == "kie":
        return ["kie"]
    if preferencia == "fal":
        return ["fal"]
    return ["kie", "fal"] if allow_fallback else ["kie"]


def cmd_generate(args: argparse.Namespace, kind: str) -> int:
    try:
        model = catalog.get(args.model)
    except KeyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_VALIDATION
    if model.kind != kind:
        print(f"error: {model.key} genera {model.kind}, no {kind}. "
              f"Usa el subcomando '{model.kind}'.", file=sys.stderr)
        return EXIT_VALIDATION

    log = make_logger(args.quiet)
    opts = catalog.apply_defaults(model, build_options(args))

    errores = catalog.validate(model, opts)
    if errores:
        print("error: parametros invalidos", file=sys.stderr)
        for e in errores:
            print(f"  - {e}", file=sys.stderr)
        print(f"\nEjecuta 'genmedia.py models' para ver los valores validos de {model.key}.",
              file=sys.stderr)
        return EXIT_VALIDATION

    try:
        cfg = providers.Config.load()
        opts = resolve_assets(opts, cfg, args.dry_run, log)
        orden = provider_order(args.provider, not args.no_fallback)
        peticiones = {p: catalog.build(model, p, opts) for p in orden}
    except ConfigError as exc:
        print(f"error de configuracion: {exc}", file=sys.stderr)
        return EXIT_CONFIG
    except GenerationError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_GENERATION

    if args.dry_run:
        salida = {
            "model": model.key,
            "kind": model.kind,
            "provider_order": orden,
            "requests": {
                p: {"endpoint": r.endpoint, "payload": r.payload, "notes": r.notes}
                for p, r in peticiones.items()
            },
        }
        print(json.dumps(salida, indent=2, ensure_ascii=False))
        return EXIT_OK

    timeout = args.timeout or (300 if kind == "image" else 1200)
    interval = 3 if kind == "image" else 10

    urls: list[str] = []
    notas: list[str] = []
    intentos: list[str] = []
    usados: list[str] = []
    creditos = 0.0
    empezado = time.monotonic()

    try:
        while len(urls) < opts.n:
            resultado = providers.run_with_fallback(
                peticiones, orden, cfg, timeout=timeout, interval=interval, log=log
            )
            urls.extend(resultado.urls)
            notas.extend(n for n in resultado.notes if n not in notas)
            intentos.extend(resultado.attempts)
            usados.append(resultado.provider)
            creditos += resultado.credits or 0
            # Si el proveedor genero varias de una vez (fal con num_images), ya esta.
            if len(resultado.urls) >= opts.n:
                break
    except ConfigError as exc:
        print(f"error de configuracion: {exc}", file=sys.stderr)
        return EXIT_CONFIG
    except GenerationError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_GENERATION

    urls = urls[: opts.n]
    destino = Path(args.out).expanduser()
    marca = datetime.now().strftime("%Y%m%d-%H%M%S")
    base = f"{model.key}-{slugify(opts.prompt)}-{marca}"
    ficheros: list[str] = []

    try:
        for i, url in enumerate(urls):
            sufijo = f"-{i + 1}" if len(urls) > 1 else ""
            ext = guess_extension(url, kind, opts.output_format)
            ficheros.append(str(providers.download(url, destino / f"{base}{sufijo}{ext}", log)))
    except GenerationError as exc:
        print(f"error al descargar: {exc}", file=sys.stderr)
        print("URLs generadas (validas unas horas):", file=sys.stderr)
        for url in urls:
            print(f"  {url}", file=sys.stderr)
        return EXIT_GENERATION

    resumen = {
        "model": model.key,
        "providers_used": usados,
        "fallback_used": "fal" in usados and orden[0] == "kie",
        "files": ficheros,
        "urls": urls,
        "elapsed_seconds": round(time.monotonic() - empezado, 1),
        "credits_consumed": creditos or None,
        "notes": notas,
        "failed_attempts": intentos,
    }

    if args.json:
        print(json.dumps(resumen, indent=2, ensure_ascii=False))
    else:
        print(f"\nListo en {resumen['elapsed_seconds']}s via {', '.join(usados)}")
        for f in ficheros:
            print(f"  {f}")
        if resumen["fallback_used"]:
            print("\n  Aviso: Kie fallo y el resultado viene de fal.ai (coste y estilo pueden variar).")
            for intento in intentos:
                print(f"    {intento}")
        for nota in notas:
            print(f"  Nota: {nota}")
    return EXIT_OK


# --------------------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------------------


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--model", required=True, help="clave del modelo (ver 'models')")
    parser.add_argument("--prompt", required=True, help="descripcion de lo que quieres generar")
    parser.add_argument("--out", default="output", help="carpeta de destino (def. output/)")
    parser.add_argument("--provider", choices=("auto", "kie", "fal"), default="auto",
                        help="auto = Kie con respaldo en fal (def.)")
    parser.add_argument("--no-fallback", action="store_true",
                        help="no saltar a fal.ai si Kie falla")
    parser.add_argument("--aspect-ratio", help="proporcion, p.ej. 16:9")
    parser.add_argument("--resolution", help="resolucion segun el modelo")
    parser.add_argument("--ref", action="append", metavar="RUTA_O_URL",
                        help="imagen de referencia (repetible)")
    parser.add_argument("--timeout", type=int, help="segundos maximos de espera")
    parser.add_argument("--dry-run", action="store_true",
                        help="muestra el payload de cada proveedor sin generar nada")
    parser.add_argument("--json", action="store_true", help="salida en JSON")
    parser.add_argument("-q", "--quiet", action="store_true", help="sin mensajes de progreso")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="genmedia.py",
        description="Generacion de imagen y video via Kie.ai con respaldo en fal.ai.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_models = sub.add_parser("models", help="lista los modelos y sus parametros")
    p_models.add_argument("--json", action="store_true")

    p_img = sub.add_parser("image", help="genera o edita una imagen")
    add_common(p_img)
    p_img.add_argument("--format", choices=("png", "jpg", "webp"), help="formato de salida")
    p_img.add_argument("--n", type=int, default=1, help="numero de imagenes (def. 1)")
    p_img.add_argument("--seed", type=int, help="semilla para reproducir un resultado")

    p_vid = sub.add_parser("video", help="genera un video")
    add_common(p_vid)
    p_vid.add_argument("--duration", help="duracion en segundos")
    p_vid.add_argument("--first-frame", metavar="RUTA_O_URL", help="imagen de partida")
    p_vid.add_argument("--last-frame", metavar="RUTA_O_URL", help="imagen de cierre")
    p_vid.add_argument("--ref-video", action="append", metavar="RUTA_O_URL",
                       help="video de referencia (solo Seedance, repetible)")
    p_vid.add_argument("--ref-audio", action="append", metavar="RUTA_O_URL",
                       help="audio de referencia (solo Seedance, repetible)")
    p_vid.add_argument("--quality", choices=("quality", "fast", "lite"),
                       help="variante de Veo 3.1")
    p_vid.add_argument("--mode", choices=("std", "pro", "4K"), help="modo de Kling 3.0")
    p_vid.add_argument("--negative-prompt", help="que evitar en el resultado")
    audio = p_vid.add_mutually_exclusive_group()
    audio.add_argument("--audio", dest="audio", action="store_true", default=None,
                       help="generar audio nativo")
    audio.add_argument("--no-audio", dest="audio", action="store_false",
                       help="video sin audio")

    args = parser.parse_args(argv)
    if args.command == "models":
        return cmd_models(args)
    return cmd_generate(args, args.command)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\ncancelado", file=sys.stderr)
        sys.exit(130)
