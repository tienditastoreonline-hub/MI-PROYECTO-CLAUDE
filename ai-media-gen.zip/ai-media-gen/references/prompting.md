# Cómo pedirle las cosas a cada modelo

Cada modelo responde a un tipo de indicación distinta. Lo que sigue no son reglas
mágicas: son las palancas que más cambian el resultado en cada uno.

## Imagen

### GPT Image 2

Es el que mejor entiende instrucciones largas y literales, y el único en el que conviene
detallar el texto que debe aparecer dentro de la imagen. Escribe el texto exacto entre
comillas y di dónde va y con qué peso tipográfico; los demás modelos lo deforman.

> Cartel A3. Titular "REBAJAS 40%" en sans-serif condensada muy pesada, arriba a la
> izquierda, blanco sobre fondo granate. Debajo, en cuerpo pequeño, "hasta el 30 de junio".
> Foto de producto centrada, luz de estudio con sombra suave a la derecha.

Para producto funciona describir la luz (clave, relleno, rebote) y el material de la
superficie. Para composición, di el encuadre en términos fotográficos: plano cenital,
tres cuartos, contrapicado.

### Nano Banana Pro

Da buenos resultados con descripciones más cortas y visuales que GPT Image 2. Rinde
especialmente bien cuando le das referencias de estilo con `--ref` en vez de intentar
describir el estilo con palabras.

### Nano Banana 2

Está pensado para edición. La instrucción debe ser una orden concreta sobre lo que
cambia, no una descripción de la imagen entera — lo que no mencionas, se queda igual:

> quita el fondo y déjalo blanco puro, conserva la sombra de contacto

> cambia la camiseta a azul marino, no toques la cara ni el pelo

Cuando pases varias referencias, di explícitamente qué papel juega cada una ("usa la
primera como personaje y la segunda como fondo"): con 14 imágenes posibles, el orden
por sí solo no basta para que acierte.

## Vídeo

### Seedance 2.5

Es el que mejor mantiene un personaje a lo largo de la toma, y el único que llega a 30 s.
Descríbelo por tramos temporales y con lenguaje de cámara; si lo dejas abierto tiende a
rellenar con movimiento genérico.

> 0-5 s: plano medio, la mujer mira por la ventana. 5-12 s: la cámara se desplaza a la
> derecha en travelling lento mientras ella se gira. 12-20 s: primer plano de su cara,
> profundidad de campo corta.

Con `--duration auto` el modelo elige la duración que le pide el contenido, lo que suele
dar mejor ritmo que forzar un número. Genera audio de forma nativa y sincronizada: si no
lo quieres, `--no-audio` sale más barato.

### Veo 3.1

El más fotorrealista, pero corto (4, 6 u 8 s). Responde bien a vocabulario de rodaje real:
tipo de lente, grano, temperatura de color, tipo de movimiento.

> Plano fijo, lente 35 mm, hora dorada, grano fino de película. Un hombre cruza el encuadre
> de izquierda a derecha; el polvo flota en el contraluz.

Genera diálogo y ambiente sincronizados. Escribe el diálogo entre comillas si lo quieres.

### Kling 3.0

El más fiel cuando partes de una imagen: respeta la composición y la identidad del
personaje mejor que los otros dos. Con `--first-frame`, el prompt debe describir **solo el
movimiento**, no la escena — la escena ya está en la imagen.

> la cámara se acerca lentamente mientras ella sonríe y ladea la cabeza

Admite personajes recurrentes vía `kling_elements` y referencias `@nombre` dentro del
prompt (ver `kie.md`; no está expuesto en el CLI). Con `--mode 4K` sube la resolución y
también el coste.

## Costes orientativos

Cifras aproximadas y **sujetas a cambio**. La fuente de verdad es https://kie.ai/pricing;
la salida `--json` incluye `credits_consumed` cuando el proveedor lo reporta.

| Modelo | Orden de magnitud |
|---|---|
| Nano Banana 2 | el más barato por imagen; 2K y 4K multiplican la tarifa base |
| Nano Banana Pro | intermedio, en torno a unos céntimos por imagen |
| GPT Image 2 | el más caro de los tres de imagen |
| Seedance 2.5 | se factura por segundo; 30 s cuesta unas 6 veces lo que 5 s |
| Veo 3.1 | caro en variante `quality`; `fast` cuesta bastante menos |
| Kling 3.0 | por segundo; `--mode 4K` multiplica el coste |

Dos consecuencias prácticas: iterar en `1K` y subir la resolución solo en la versión final
ahorra bastante, y probar el encuadre con Nano Banana 2 antes de lanzarlo en GPT Image 2
sale a cuenta cuando la composición aún no está decidida.
