# fal.ai — referencia de API

Proveedor de respaldo. Se usa cuando Kie falla, o forzando `--provider fal`.
Documentación oficial: https://docs.fal.ai

## Contenido

- [Autenticación y cola](#autenticación-y-cola)
- [Endpoints por modelo](#endpoints-por-modelo)
- [Diferencias con Kie que importan](#diferencias-con-kie-que-importan)
- [Subida de ficheros](#subida-de-ficheros)

## Autenticación y cola

```
Authorization: Key <FAL_KEY>
```

```
POST https://queue.fal.run/<endpoint_id>
{ ...input... }
  -> { "status": "IN_QUEUE", "request_id": "...",
       "status_url": "...", "response_url": "...", "cancel_url": "..." }

GET <status_url>    -> { "status": "IN_QUEUE|IN_PROGRESS|COMPLETED", "queue_position": 0 }
GET <response_url>  -> el resultado
```

**Usa `status_url` y `response_url` tal como vienen en la respuesta.** Reconstruirlas a
mano parece trivial (`<base>/requests/<id>/status`) pero falla en los endpoints con
subrutas: en `fal-ai/kling-video/v3/pro/image-to-video` la base de consulta es
`fal-ai/kling-video`, no la ruta completa de envío. Es una fuente clásica de 404.

Se puede añadir `?fal_webhook=<url>` al envío para recibir el resultado por webhook en
lugar de consultar en bucle.

## Endpoints por modelo

| Modelo | Texto → | Con imagen → |
|---|---|---|
| GPT Image 2 | `openai/gpt-image-2/text-to-image` | `openai/gpt-image-2/edit-image` |
| Nano Banana Pro | `fal-ai/nano-banana-pro` | `fal-ai/nano-banana-pro/edit` |
| Nano Banana 2 | `fal-ai/nano-banana-2` | `fal-ai/nano-banana-2/edit` |
| Seedance 2.5 | `bytedance/seedance-2.5/text-to-video` | `/image-to-video` · `/reference-to-video` |
| Veo 3.1 | `fal-ai/veo3.1` | `fal-ai/veo3.1/image-to-video` |
| Kling 3.0 | `fal-ai/kling-video/v3/{pro,standard}/text-to-video` | `.../image-to-video` |

### Esquemas de entrada

**GPT Image 2** — `prompt`, `image_size` (preset `square_hd|square|portrait_4_3|portrait_16_9|landscape_4_3|landscape_16_9|auto` o `{width, height}`), `quality` (`auto|low|medium|high`, def. `high`), `num_images`, `output_format` (`jpeg|png|webp`), `sync_mode`. En `edit-image`: `image_urls` (máx. 16) y `mask_url`.

**Nano Banana Pro / 2** — `prompt`, `aspect_ratio` (`auto 21:9 16:9 3:2 4:3 5:4 1:1 4:5 3:4 2:3 9:16`), `resolution` (`1K|2K|4K`), `output_format` (`jpeg|png|webp`), `num_images`, `seed`, `system_prompt`, `enable_web_search`, `safety_tolerance` (1–6). En `/edit`: `image_urls`.

**Seedance 2.5** — `prompt`, `resolution` (`480p|720p`), `duration` (`auto` o `4`–`30`), `generate_audio`, `aspect_ratio` (`auto 21:9 16:9 4:3 1:1 3:4 9:16`).
- `image-to-video`: `image_url` (obligatorio), `end_image_url`. Solo admite `aspect_ratio: auto` — lo hereda de la imagen.
- `reference-to-video`: `image_urls` (30), `video_urls` (10), `audio_urls` (10).

**Veo 3.1** — `prompt`, `duration` (`4s|6s|8s`), `resolution` (`720p|1080p|4k`), `aspect_ratio` (`auto|16:9|9:16`), `generate_audio`, `negative_prompt`, `seed`, `auto_fix`, `safety_tolerance`. En `image-to-video`: `image_url`.

**Kling 3.0** — `prompt` o `multi_prompt` (excluyentes), `duration` (`"3"`–`"15"`), `generate_audio`, `negative_prompt` (def. `"blur, distort, and low quality"`), `cfg_scale` (def. 0.5), `elements`, `shot_type` (`customize|intelligent`). En `image-to-video`: `start_image_url` (obligatorio), `end_image_url`; **no acepta `aspect_ratio`**, lo hereda de la imagen. En `text-to-video`: `aspect_ratio` (`16:9|9:16|1:1`).

### Salida

- Imagen: `{ "images": [ { "url", "content_type", "file_name", "width", "height" } ], "description" }`
- Vídeo: `{ "video": { "url", "content_type", "file_name", "file_size" }, "seed" }`

## Diferencias con Kie que importan

Estas son las que rompen si se copia un payload de un proveedor al otro:

| Concepto | Kie | fal |
|---|---|---|
| Duración de Veo | entero `8` | cadena `"8s"` |
| Ratio automático de Seedance | `"adaptive"` | `"auto"` |
| Formato JPEG | `"jpg"` | `"jpeg"` |
| Audio en Kling | `sound` | `generate_audio` |
| Tamaño en GPT Image 2 | `aspect_ratio` + `resolution` | `image_size` (`{width,height}`) |
| Seedance i2v | mismo modelo + `first_frame_url` | endpoint distinto + `image_url` |
| Ratios extremos (`8:1`, `1:4`…) | soportados en Nano Banana 2 | no existen |
| Variantes de Veo | `veo3` / `veo3_fast` / `veo3_lite` | una sola |
| Modo 4K de Kling | `mode: "4K"` | no existe |

`scripts/catalog.py` ya aplica todas estas conversiones y deja constancia en `notes`
cuando la traducción pierde algo.

## Subida de ficheros

Dos pasos:

```
POST https://rest.alpha.fal.ai/storage/auth/token?storage_type=fal-cdn-v3
     Authorization: Key <FAL_KEY>          -> { "token": "...", "base_url": "..." }

POST <base_url>/files/upload
     Authorization: Bearer <token>
     Content-Type: <mime del fichero>
     <bytes>                                -> { "access_url": "..." }
```

La skill prefiere subir a Kie y reutilizar esa URL también en fal, para no tener que
resubir si hay que cambiar de proveedor a mitad.
