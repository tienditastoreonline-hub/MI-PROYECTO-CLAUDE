# Kie.ai — referencia de API

Consulta esta ficha cuando necesites un parámetro que el CLI no expone o cuando haya que
interpretar un error del proveedor. Documentación oficial: https://docs.kie.ai

## Contenido

- [Autenticación](#autenticación)
- [Flujo general (mercado)](#flujo-general-mercado)
- [Veo 3.1: endpoint aparte](#veo-31-endpoint-aparte)
- [Modelos y parámetros](#modelos-y-parámetros)
- [Subida de ficheros](#subida-de-ficheros)
- [Códigos de error](#códigos-de-error)

## Autenticación

```
Authorization: Bearer <KIE_API_KEY>
Content-Type: application/json
```

La clave se crea en https://kie.ai/api-key.

## Flujo general (mercado)

Todas las generaciones son asíncronas: la creación devuelve un `taskId`, no el resultado.

```
POST https://api.kie.ai/api/v1/jobs/createTask
{ "model": "<id>", "input": { ... }, "callBackUrl": "<opcional>" }
  -> { "code": 200, "msg": "success", "data": { "taskId": "..." } }

GET  https://api.kie.ai/api/v1/jobs/recordInfo?taskId=<id>
  -> { "code": 200, "data": {
         "state": "waiting|queuing|generating|success|fail",
         "resultJson": "<string con JSON dentro>",
         "failCode": "", "failMsg": "",
         "progress": 0, "creditsConsumed": 0, "costTime": 0 } }
```

Dos trampas de este contrato:

1. **`resultJson` llega como string**, no como objeto. Hay que parsearlo por separado
   para llegar a `resultUrls`.
2. **Un HTTP 200 no garantiza éxito**: el error real puede venir en el campo `code` del
   cuerpo. Hay que mirar los dos sitios.

## Veo 3.1: endpoint aparte

Veo no está en el mercado. Usa rutas, nombres de campo y estados propios — por eso
`providers.py` lo trata como un caso separado en lugar de forzarlo al flujo común.

```
POST https://api.kie.ai/api/v1/veo/generate
{ "prompt": "...", "model": "veo3|veo3_fast|veo3_lite",
  "aspect_ratio": "16:9|9:16|Auto", "resolution": "720p|1080p|4k",
  "duration": 4|6|8, "imageUrls": ["..."],
  "generationType": "TEXT_2_VIDEO|FIRST_AND_LAST_FRAMES_2_VIDEO|REFERENCE_2_VIDEO",
  "enableTranslation": false, "watermark": "..." }

GET  https://api.kie.ai/api/v1/veo/record-info?taskId=<id>
  -> { "data": { "successFlag": 0|1|2|3,
                 "errorCode": null, "errorMessage": null,
                 "response": { "resultUrls": [...], "originUrls": [...],
                               "fullResultUrls": [...], "resolution": "1080p" } } }
```

`successFlag`: 0 generando · 1 éxito · 2 y 3 fallo. Nota que aquí el estado es un entero,
mientras que en el mercado es la cadena `state`.

`resultUrls` es el vídeo final; `originUrls` es el original antes de extender. No los
confundas: son vídeos distintos.

`REFERENCE_2_VIDEO` solo existe en las variantes `fast` y `lite`. Si se omite
`generationType`, Kie lo deduce de los campos enviados — que es lo que hacemos cuando solo
hay una imagen de partida, para no perder la variante `veo3` de calidad.

## Modelos y parámetros

### GPT Image 2
- `gpt-image-2-text-to-image` · `gpt-image-2-image-to-image`
- `prompt` (1–20.000 car.), `aspect_ratio`, `resolution` (`1K|2K|4K`)
- `input_urls` (1–16) solo en image-to-image
- Ratios: `auto 1:1 3:2 2:3 4:3 3:4 5:4 4:5 16:9 9:16 2:1 1:2 3:1 1:3 21:9 9:21`.
  En 2K y 4K **no** se admiten `5:4 4:5 3:1 1:3 9:21`.

### Nano Banana Pro
- `nano-banana-pro`
- `prompt` (máx. 10.000 car.), `image_input` (hasta 8, jpeg/png/webp, 30 MB c/u)
- `aspect_ratio` (`1:1 2:3 3:2 3:4 4:3 4:5 5:4 9:16 16:9 21:9 auto`, def. `1:1`)
- `resolution` (`1K|2K|4K`, def. `1K`), `output_format` (`png|jpg`, def. `png`)

### Nano Banana 2
- `nano-banana-2`
- `prompt` (máx. 20.000 car.), `image_input` (hasta 14)
- `aspect_ratio`: los de Pro más `1:4 4:1 1:8 8:1`; def. `auto`
- `resolution` (`1K|2K|4K`, def. `1K`), `output_format` (`png|jpg`, def. `jpg`)

### Seedance 2.5
- `bytedance/seedance-2-5`
- `prompt` (máx. 30.000 car.)
- `duration` entero 4–30, o `-1` para que el modelo elija (def. 5)
- `resolution` (`480p|720p`, def. `720p`)
- `aspect_ratio` (`1:1 4:3 3:4 16:9 9:16 21:9 adaptive`, def. `adaptive` — ojo, aquí el
  valor automático se llama `adaptive`, no `auto`)
- `generate_audio` (def. `true`), `output_format` (`mp4|mov`)
- `first_frame_url`, `last_frame_url`
- `reference_image_urls` (30), `reference_video_urls` (10), `reference_audio_urls` (10)
- No expuestos en el CLI: `return_last_frame`, `web_search`, `nsfw_checker`

### Kling 3.0
- `kling-3.0/video`
- `prompt` (admite `@nombre_elemento` para referirse a elementos definidos)
- `duration` string `"3"`–`"15"` (def. `"5"`)
- `aspect_ratio` (`16:9|9:16|1:1`), `mode` (`std|pro|4K`, def. `pro`)
- `sound` (def. `false`), `image_urls` (primer y último frame)
- No expuestos en el CLI: `multi_shots` + `multi_prompt` (lista de tomas con `prompt` y
  `duration` por toma) y `kling_elements` (máx. 3 por tarea, para personajes recurrentes)
- Resolución según modo: `std` 720p · `pro` 1080p · `4K` 2160p

## Subida de ficheros

```
POST https://kieai.redpandaai.co/api/file-base64-upload
{ "base64Data": "data:image/png;base64,...", "uploadPath": "...", "fileName": "..." }
```

También existe `file-stream-upload` (multipart, ~33 % más eficiente para ficheros grandes)
y `file-url-upload`. Los ficheros subidos **se borran a los 3 días**: sirven para generar,
no como almacenamiento.

## Códigos de error

| Código | Significado | ¿Reintentar? |
|---|---|---|
| 401 | clave inválida o caducada | no |
| 402 | sin créditos | no — pasar a fal |
| 404 | endpoint o tarea inexistente | no |
| 422 | parámetros rechazados | no — revisar el payload |
| 429 | límite de peticiones | sí, con espera |
| 433 | modelo no disponible temporalmente | sí |
| 455 | mantenimiento | sí |
| 500/501/505 | error del servidor | sí |
