---
name: ai-media-gen
description: >-
  Genera y edita imágenes y vídeos con IA usando Kie.ai como proveedor principal y fal.ai
  como respaldo automático, con los modelos GPT Image 2, Nano Banana Pro, Nano Banana 2,
  Seedance 2.5, Veo 3.1 y Kling 3.0. Úsala siempre que el usuario quiera crear, generar,
  diseñar o editar una imagen, foto, ilustración, render, logo, banner, portada, thumbnail
  o mockup visual, y siempre que quiera un vídeo, clip, animación, spot, reel o
  image-to-video — incluso si no nombra ningún modelo ni menciona IA, y también cuando solo
  describe el resultado que quiere ver ("hazme una foto de...", "necesito un vídeo donde...",
  "quítale el fondo a esta imagen", "anima esta foto"). Aplica igualmente en inglés
  (generate/create an image, make a video, edit this photo, animate this picture) y cuando
  se nombre cualquiera de los modelos soportados.
---

# Generación de imagen y vídeo

Un único CLI cubre los seis modelos. Habla con Kie.ai primero y, si Kie falla, repite la
generación en fal.ai traduciendo los parámetros — sin que haya que reconstruir nada a mano.

```bash
python .claude/skills/ai-media-gen/scripts/genmedia.py models
```

Ese comando imprime cada modelo con sus parámetros y valores válidos. Consúltalo cuando
dudes en lugar de adivinar un valor: el CLI valida antes de gastar créditos, pero un
`--aspect-ratio` inventado es una ida y vuelta perdida.

## Qué modelo elegir

| Necesidad | Modelo | Clave |
|---|---|---|
| Máxima calidad, texto legible dentro de la imagen, foto de producto | GPT Image 2 | `gpt-image-2` |
| Imagen profesional a menor coste | Nano Banana Pro | `nano-banana-pro` |
| Editar una imagen, o generar en volumen a bajo coste | Nano Banana 2 | `nano-banana-2` |
| Vídeo de hasta 30 s con consistencia de personaje | Seedance 2.5 | `seedance-2.5` |
| Vídeo fotorrealista con máximo detalle (≤ 8 s) | Veo 3.1 | `veo-3.1` |
| Animar una imagen o personaje de referencia con máxima fidelidad | Kling 3.0 | `kling-3.0` |

Cuando el usuario no nombre modelo, decide por la intención que expresa:

- Dice "profesional", "portada", "para cliente", "producto", o el diseño lleva texto
  dentro de la imagen → **GPT Image 2**. Es el que mejor renderiza tipografía.
- Dice "rápido", "barato", "unas cuantas opciones", "para probar" → **Nano Banana 2**.
- Aporta una imagen y quiere modificarla (quitar fondo, cambiar un color, componer con
  otra) → **Nano Banana 2** con `--ref`. Está pensado para edición y es el más barato.
- Quiere calidad alta pero el coste importa → **Nano Banana Pro**, el término medio.
- Aporta una imagen y quiere que se mueva → **Kling 3.0** con `--first-frame`.
- Quiere un vídeo largo, o que un personaje se mantenga igual de principio a fin →
  **Seedance 2.5**, el único que llega a 30 s.
- Quiere que parezca grabado con cámara real → **Veo 3.1**.

## Cómo se invoca

```bash
python .claude/skills/ai-media-gen/scripts/genmedia.py image \
  --model gpt-image-2 --prompt "botella de perfume sobre mármol, luz de estudio" \
  --aspect-ratio 16:9 --resolution 2K --out output/
```

```bash
python .claude/skills/ai-media-gen/scripts/genmedia.py image \
  --model nano-banana-2 --prompt "quita el fondo y déjalo blanco" \
  --ref fotos/producto.jpg --out output/
```

```bash
python .claude/skills/ai-media-gen/scripts/genmedia.py video \
  --model seedance-2.5 --prompt "la cámara rodea al personaje mientras camina" \
  --duration 15 --first-frame output/personaje.png --out output/
```

`--ref`, `--first-frame` y `--last-frame` aceptan tanto rutas locales como URLs: los
ficheros locales se suben solos y la URL resultante sirve para ambos proveedores.

Flags que conviene conocer: `--provider kie|fal|auto`, `--no-fallback`, `--n`,
`--json` (salida estructurada), `--dry-run` (muestra el payload de cada proveedor sin
generar nada — útil para depurar un rechazo sin pagarlo dos veces).

Los códigos de salida distinguen el tipo de problema: `2` configuración, `3` parámetros,
`4` generación. Si ves un `2`, el usuario todavía no ha puesto sus claves en `.env`.

## Cómo trabajar con esto

**Los vídeos tardan minutos.** Un Seedance o un Veo pueden estar varios minutos en cola.
Lánzalos en segundo plano y dile al usuario que está corriendo, en vez de dejar la sesión
bloqueada esperando. Las imágenes suelen resolverse en menos de un minuto y pueden ir en
primer plano.

**Confirma antes de gastar de más.** Si el usuario no fijó modelo y la opción razonable es
cara — un vídeo largo, 4K, varias imágenes con GPT Image 2 — dile qué vas a lanzar y
cuánto cuesta aproximadamente antes de hacerlo. Un vídeo de 30 s no es un experimento
barato, y equivocarse de modelo se paga igual.

**Di siempre si se usó el respaldo.** Cuando la salida trae `fallback_used`, el resultado
viene de fal.ai: el coste cambia y el resultado puede diferir ligeramente del que habría
dado Kie. El usuario necesita saberlo para juzgar lo que está viendo.

**Repasa las notas.** El campo `notes` recoge las traducciones que perdieron algo por el
camino (un ratio que fal no soporta, un parámetro que ese endpoint ignora). Si una nota
explica por qué el resultado no es como se pedía, cuéntaselo en vez de dejar que lo
descubra mirando el archivo.

**Itera sobre el resultado, no desde cero.** Si una imagen casi funciona, pásala como
`--ref` a `nano-banana-2` con la corrección concreta. Sale más barato que regenerar y
conserva lo que ya estaba bien.

## Configuración

Las claves se leen de `.env` en la raíz del proyecto (`KIE_API_KEY` y `FAL_KEY`), nunca de
variables de entorno del sistema. `.env.example` tiene la plantilla. Sin `FAL_KEY` la skill
funciona igual, pero se queda sin respaldo: si Kie cae, no hay generación.

## Referencias

Consúltalas solo cuando el CLI se quede corto:

- `references/kie.md` — endpoints, parámetros completos por modelo (incluidos los que el
  CLI no expone, como `multi_prompt` de Kling o `web_search` de Seedance) y códigos de error.
- `references/fal.md` — mecánica de la cola, ids de endpoint y esquemas de entrada/salida.
- `references/prompting.md` — cómo escribir el prompt para cada modelo y costes orientativos.

Para añadir un modelo nuevo o cambiar cómo se traduce un parámetro, el sitio es
`scripts/catalog.py`: cada modelo declara sus valores válidos y dos funciones que
construyen el payload de cada proveedor.
